import fs from "fs";
import path from "path";
import crypto from "crypto";
import url from "url";
import console from "node:console"

const __filename = url.fileURLToPath(import.meta.url);

// console.log(fs);
// console.log(path);
// console.log(__filename);

// console.log(path.dirname(__filename));
// console.log(__filename);
// console.log(crypto);

console.log(process)
